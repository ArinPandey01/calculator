import { useEffect, useRef, useState } from "react";

const buttons = [
  ["C", "clear"], ["(", "("], [")", ")"], ["⌫", "backspace"], ["%", "%"], ["x!", "fact("], ["x^", "pow("],
  ["7", "7"], ["8", "8"], ["9", "9"], ["*", "*"], ["/", "/"], ["ln", "ln("], ["e", "e"],
  ["4", "4"], ["5", "5"], ["6", "6"], ["+", "+"], ["x²", "^2"], ["log", "log("], ["cos", "cos("],
  ["1", "1"], ["2", "2"], ["3", "3"], ["-", "-"], ["√", "sqrt("], ["sin", "sin("], ["tan", "tan("],
  ["±", "negate"], ["0", "0"], [".", "."], ["=", "calculate"], ["π", "pi"], ["°", "deg("], ["rad", "rad("],
];

function App() {
  const [expression, setExpression] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [history, setHistory] = useState([]);
  const [showHistory, setShowHistory] = useState(false);

  const inputRef = useRef(null);

  async function clearHistory() {
    try {
      await fetch("http://localhost:8080/history", {
        method: "DELETE",
      });

      setHistory([]);
    } catch {
      setError("Could not clear history");
    }
  }

  useEffect(() => {
    fetchHistory();
  }, []);

  useEffect(() => {
    inputRef.current?.focus();

    function handleGlobalKeyDown(event) {
      const allowedChars = "0123456789+-*/%.(), ";

      if (event.key === "Enter") {
        event.preventDefault();
        calculate();
        return;
      }

      if (event.key === "Backspace") {
        event.preventDefault();
        backspace();
        return;
      }

      if (event.key === "Escape") {
        event.preventDefault();
        clear();
        return;
      }

      if (allowedChars.includes(event.key)) {
        event.preventDefault();
        append(event.key);
      }
    }

    window.addEventListener("keydown", handleGlobalKeyDown);

    return () => {
      window.removeEventListener("keydown", handleGlobalKeyDown);
    };
  }, [expression]);

  function focusInput() {
    inputRef.current?.focus();
  }

  function append(value) {
    setExpression((prev) => prev + value);
    setError("");
    focusInput();
  }

  function clear() {
    setExpression("");
    setResult(null);
    setError("");
    focusInput();
  }

  function backspace() {
    setExpression((prev) => prev.slice(0, -1));
    focusInput();
  }

  function negate() {
    setExpression((prev) => prev + "-");
    focusInput();
  }

  async function fetchHistory() {
    try {
      const response = await fetch("http://localhost:8080/history");
      const data = await response.json();
      setHistory(data);
    } catch {
      setError("Could not fetch history");
    }
  }

  async function calculate() {
    setError("");
    setResult(null);

    try {
      const response = await fetch("http://localhost:8080/calculate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ expression }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || "Something went wrong");
        return;
      }

      setResult(data.result);
      await fetchHistory();
    } catch {
      setError("Could not connect to backend");
    } finally {
      focusInput();
    }
  }

  function handleButton(action) {
    if (action === "clear") return clear();
    if (action === "backspace") return backspace();
    if (action === "calculate") return calculate();
    if (action === "negate") return negate();

    append(action);
  }

  return (
    <div style={styles.page}>
      <div style={styles.calculator}>
        <input
          ref={inputRef}
          style={styles.display}
          type="text"
          value={expression}
          readOnly
          placeholder="0"
        />

        <div style={styles.grid}>
          {buttons.map(([label, action]) => (
            <button
              key={label}
              style={{
                ...styles.button,
                ...(label === "C" || label === "=" ? styles.orange : {}),
                ...(label.match(/[0-9.]/) ? styles.number : {}),
                ...(label !== "C" && label !== "=" && !label.match(/[0-9.]/)
                  ? styles.function
                  : {}),
              }}
              onClick={() => handleButton(action)}
            >
              {label}
            </button>
          ))}
        </div>

        {result !== null && <div style={styles.result}>Result: {result}</div>}

        {error && <div style={styles.error}>Error: {error}</div>}

        <button
          style={styles.historyButton}
          onClick={() => setShowHistory(!showHistory)}
        >
          {showHistory ? "Hide History" : "Show History"}
        </button>

        {showHistory && (
          <div style={styles.historyPanel}>
            <h2 style={styles.historyTitle}>History</h2>

            <button style={styles.clearHistoryButton} onClick={clearHistory}>
              Clear History
            </button>

            {history.length === 0 && (
              <div style={styles.historyItem}>No history yet</div>
            )}

            {[...history].reverse().map((item) => (
              <div
                key={item.id}
                style={styles.historyItem}
                onClick={() => {
                  setExpression(item.expression);
                  focusInput();
                }}
              >
                <div>{item.expression}</div>
                <div>= {item.result}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#f5f3dc",
    display: "flex",
    justifyContent: "center",
    alignItems: "flex-start",
    paddingTop: "30px",
    fontFamily: "Arial, sans-serif",
  },
  calculator: {
    width: "620px",
    padding: "24px",
    borderRadius: "12px",
  },
  display: {
    width: "100%",
    height: "40px",
    fontSize: "22px",
    padding: "6px 10px",
    marginBottom: "18px",
    background: "#333",
    color: "#eaf6ff",
    border: "none",
    borderRadius: "6px",
    boxSizing: "border-box",
    textAlign: "left",
    outline: "none",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(7, 1fr)",
    gap: "8px",
  },
  button: {
    height: "38px",
    border: "none",
    borderRadius: "5px",
    fontSize: "17px",
    cursor: "pointer",
  },
  number: {
    background: "#999",
    color: "#111",
  },
  function: {
    background: "#69dff0",
    color: "#111",
  },
  orange: {
    background: "#ffbd59",
    color: "#111",
  },
  result: {
    marginTop: "20px",
    fontSize: "22px",
    fontWeight: "bold",
    textAlign: "center",
    color: "#999",
  },
  error: {
    marginTop: "20px",
    color: "crimson",
    fontSize: "18px",
    fontWeight: "bold",
    textAlign: "center",
  },
  historyButton: {
    marginTop: "20px",
    width: "100%",
    height: "40px",
    border: "none",
    borderRadius: "6px",
    background: "#444",
    color: "#fff",
    fontSize: "16px",
    cursor: "pointer",
  },
  historyPanel: {
    marginTop: "20px",
    background: "#2c2c2c",
    borderRadius: "8px",
    padding: "14px",
    maxHeight: "300px",
    overflowY: "auto",
  },
  historyTitle: {
    color: "#fff",
    marginBottom: "12px",
  },
  historyItem: {
    background: "#444",
    color: "#fff",
    padding: "10px",
    borderRadius: "6px",
    marginBottom: "10px",
    cursor: "pointer",
  },
  clearHistoryButton: {
    width: "100%",
    height: "36px",
    border: "none",
    borderRadius: "6px",
    background: "#ffbd59",
    color: "#111",
    fontSize: "15px",
    cursor: "pointer",
    marginBottom: "12px",
  },
};


export default App;
