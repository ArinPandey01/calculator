package main

import (
	"calculator/internal/handlers"
	"fmt"
	"github.com/rs/cors"
	"net/http"
)

func main() {
	http.HandleFunc("/calculate", handlers.CalculateHandler)
	http.HandleFunc("/history", handlers.HistoryHandler)

	fmt.Println("Calculator running on http://localhost:8080")


	c := cors.New(cors.Options{
		AllowedOrigins: []string{"http://localhost:5173"},
		AllowedMethods: []string{"GET", "POST","DELETE", "OPTIONS"},
		AllowedHeaders: []string{"Content-Type"},
	})

	handler := c.Handler(http.DefaultServeMux)

	err := http.ListenAndServe(":8080", handler)

	if err != nil {
		fmt.Println("Server error:", err)
	}
}
