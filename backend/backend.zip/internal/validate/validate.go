package validate

import (
	"fmt"
	"strings"
)

func Validate(expression string) error {
	expression = strings.TrimSpace(expression)

	if expression == "" {
		return fmt.Errorf("expression is required")
	}
	if strings.Contains(expression, "//") {
		return fmt.Errorf("invalid operator: //")
	}

	if len(expression) > 500 {
		return fmt.Errorf("expression is too long")
	}

	return nil
}
